
Repository Link: https://github.com/tulsyanp/tcd-ai-group-project


Group members list and summary of contributions of each member in the team

STUDENT NUMBER - STUDENT NAME - % CONTRIBUTION - NATURE OF CONTRIBUTION

19303677 - Prateek Tulsyan - 25% - Worked on initial research for the problem statement.
                                   Worked on PCA algorithm with SVM classifier.
                                   Managed the data collection from team and also pushed it on GitHub.
                                   Worked on preparing the presentation and video.

19301913 - Mrinal Jhamb - 25% -	Worked on LDA algorithm with SVM classifier.
                                Worked on writing the report sections ‘Problem Definition and Algorithm’ and ‘Experimental Results’
                                Worked on generating the graphs using tableau.

19304374 - Shubham Dhupar - 25% - Worked on NMF algorithm with SVM classifier.
                                  Worked on report section ‘Introduction’ and ‘Abstract’
                                  Worked on final report proof reading

19300976 - Rushikesh Joshi - 25% - Worked on ICA algorithm with SVM classifier.
                                   Worked on report section ‘Related Work’ and ‘Conclusion/Future Scope’.
                                   Worked on final compilation of the report along with alignment and grammatical errors.
